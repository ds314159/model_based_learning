#' @name MelangeGaussien
#' @title Modèle de Mélange Gaussien
#' @description Implémente un modèle de mélange gaussien pour le clustering via l'algorithme EM, avec diverses hypothèses sur la variance des variables.
#' @docType class
#' @export
#' @field nb_clusters Nombre de clusters dans le mélange.
#' @field type_covariance Structure des matrices de covariance (\code{"full"}, \code{"tied"}, \code{"diag"}, ou \code{"spherical"}).
#' @field nb_initialisations Nombre de positions de départ différentes pour l'algorithme.
#' @field comment_initialiser_parametres Méthode de génération des paramètres initiaux (\code{"random"} ou \code{"kmeans"}).
#' @field proportions_ Proportions estimées pour chaque cluster.
#' @field moyennes_ Moyennes estimées pour chaque cluster.
#' @field covariances_ Matrices de covariance estimées.
#' @field prob_z_sachant_x_ Probabilités a posteriori \eqn{P(Z=k|X=x)}.
#' @field nb_iterations_realisees_ Nombre d'itérations réalisées par l'algorithme EM.
#' @field log_vraisemblance_estimee_ Log-vraisemblance courante \eqn{\ell(\theta) = \frac{1}{n}\sum_{i} \log\left(\sum_{k} p_{k} f_{k}(x_{i})\right)}.
#' @field etat_convergence_ Indicateur de convergence de l'algorithme.
#' @field epsilon_convergence Seuil de convergence.
#' @field nb_iterations_max Nombre maximal d'itérations autorisé.
#' @field regul_inversibilite Régularisation pour le calcul de l'inverse des matrices de covariance.
#' @field random_state Graine pour la reproductibilité des résultats.
#' @field evolution_logvraisemblance_estimee Historique de la log-vraisemblance à chaque itération.
#' @field evolution_relative_lv Variation relative de la log-vraisemblance à chaque itération.



## LIBRAIRIES UTILISEES ########################################################
################################################################################
################################################################################

library(methods)
library(stats)
library(ggplot2)
library(reshape2)


## CLASSE MELANGE GAUSSIEN #####################################################
################################################################################
################################################################################

MelangeGaussien <- setRefClass("MelangeGaussien",

                               ## ATTRIBUTS LA CLASSE #######################################################
                               ################################################################################

                               fields = list(

                                 ## Hyperparamètres

                                 # nombre de gaussiennes dans la densité de mélange f(x) = Σᵢ₌₁ᴷ pᵢ fᵢ(x)
                                 nb_clusters = "numeric",

                                 # Structure imposée sur les matrices de covariance Σₖ
                                 # "full": Σₖ matrices pleines distinctes
                                 # "tied": Σ = Σₖ ∀k, une seule matrice commune à tous les clusters
                                 # "diag": Σₖ matrices diagonales (K×p paramètres)
                                 # "spherical": Σₖ = σₖ²I matrices sphériques (K paramètres)
                                 type_covariance = "character",

                                 # Nombre de positions de départ θ⁽⁰⁾ différents pour l'algorithme
                                 nb_initialisations = "numeric",

                                 # Méthode de génération des paramètres initiaux θ⁽⁰⁾ = (p₁⁽⁰⁾,...,pₖ⁽⁰⁾,μ₁⁽⁰⁾,...,μₖ⁽⁰⁾,Σ₁⁽⁰⁾,...,Σₖ⁽⁰⁾)
                                 comment_initialiser_parametres = "character",

                                 ## Attributs calculés lors de l'execution d'EM

                                 # Proportions de chaque cluster dans le mélange avec contraintes: Σₖ pₖ = 1 et pₖ ≥ 0
                                 proportions_ = "numeric",

                                 # Centres des gaussiennes μₖ ∈ ℝᵖ
                                 moyennes_ = "matrix",

                                 # Matrices de covariance Σₖ
                                 covariances_ = "array",

                                 # Probabilités a posteriori tₖ(x) = P(Z=k|X=x)
                                 prob_z_sachant_x_ = "matrix",

                                 # Nombre d'itérations d'EM jusqu'à convergence
                                 nb_iterations_realisees_ = "numeric",

                                 # Log-vraisemblance courante ℓ(θ) = (1/n)Σᵢ log(Σₖ pₖ fₖ(xᵢ))
                                 log_vraisemblance_estimee_ = "numeric",

                                 # Etat de convergence de la phase ajustement
                                 etat_convergence_ = "logical",

                                 ## Bornes numériques, régularisation et reproductibilité

                                 # Seuil de convergence
                                 epsilon_convergence = "numeric",

                                 # Maximum d'itérations par
                                 nb_iterations_max = "numeric", # nombre maximal d'itérations autorisé

                                 # Régularisation pour le calcul de l'inverse des matrices de covariance
                                 regul_inversibilite = "numeric",

                                 # Graine de l'aléatoire
                                 random_state = "numeric",

                                 ## Historiques pour la visualisation

                                 # Historique de la valeur de la log-vraisemblance à chaque itération
                                 evolution_logvraisemblance_estimee = "numeric",

                                 # La convergence est évaluée via la variation relative de la log vraisemblance :
                                 #   δ⁽ᵠ⁾ = |ℓ(θ⁽ᵠ⁺¹⁾) - ℓ(θ⁽ᵠ⁾)| / |ℓ(θ⁽ᵠ⁾)|
                                 evolution_relative_lv = "numeric"

                               ),

                               ## METHODES DE LA CLASSE #######################################################
                               ################################################################################


                               methods = list(


                                 ## INSTANCIATION DE LA CLASSE ##################################################

                                 # Méthode d'instanciation d'un modèle de la classe, appelée lors d'un "MelangeGaussien$new()"

                                 initialize = function(nb_clusters=1,
                                                       type_covariance="full",
                                                       epsilon_convergence=1e-8,
                                                       regul_inversibilite=1e-10,
                                                       nb_iterations_max=50,
                                                       nb_initialisations=1,
                                                       comment_initialiser_parametres="random",
                                                       random_state=42) {

                                   nb_clusters <<- nb_clusters
                                   type_covariance <<- type_covariance
                                   epsilon_convergence <<- epsilon_convergence
                                   regul_inversibilite <<- regul_inversibilite
                                   nb_iterations_max <<- nb_iterations_max
                                   nb_initialisations <<- nb_initialisations
                                   comment_initialiser_parametres <<- comment_initialiser_parametres
                                   random_state <<- random_state
                                 },

                                 ## AJUSTEMENT DU MODELE ########################################################

                                 # Méthode d'ajustement du modèle de mélange gaussien par maximum de vraisemblance.
                                 # Implémente l'algorithme EM avec initialisations multiples pour éviter les maxima locaux.
                                 #
                                 # Args:
                                 #   X: Matrice n×p des observations (n_samples × n_features)
                                 #
                                 # La log-vraisemblance à maximiser est :
                                 #   ℓ(θ) = (1/n)∑ᵢ log(∑ₖ pₖ fₖ(xᵢ|μₖ,Σₖ))
                                 # où fₖ est la densité gaussienne de paramètres (μₖ,Σₖ)

                                 fit = function(X) {


                                   n_samples <- nrow(X)
                                   n_features <- ncol(X)

                                   # Initialisation du tracker de meilleure solution
                                   # La log-vraisemblance est initialisée à -Inf pour garantir
                                   # qu'au moins une solution sera conservée

                                   meilleur_resultat_logvraisemblance <- -Inf
                                   meilleurs_parametres <- NULL

                                   # Boucle sur les initialisations multiples
                                   # Objectif : éviter les maxima locaux en partant de plusieurs configs différentes
                                   for(init in 1:nb_initialisations) {

                                     # Réinitialisation des historiques pour cette configuration de départ
                                     evolution_logvraisemblance_estimee_initialisation_courante <- numeric()
                                     evolution_relative_lv_init <- numeric()
                                     etat_convergence_ <<- FALSE

                                     # Initialisation des paramètres θ⁽⁰⁾ = (pₖ⁽⁰⁾, μₖ⁽⁰⁾, Σₖ⁽⁰⁾)
                                     initialiser_parametres(X)


                                     # Boucle principale de l'algorithme EM
                                     # Alterne entre estimation des probabilités des clusters a posteriori (E-step)
                                     # et mise à jour des paramètres (M-step)
                                     for(n in 1:nb_iterations_max) {

                                       # Stockage de la log-vraisemblance précédente pour évaluer la convergence
                                       log_vraisemblance_estimee_precedente <- ifelse(n == 1, -Inf, log_vraisemblance_estimee_)



                                       # Étape E :
                                       # Varieté de l algorithme EXPECTATION plus stable numériquement
                                       # calcul les probabilités a posteriori des clusters et les stocke dans l'attribut de classe
                                       # prob_z_sachant_x = tₖ(xᵢ) = P(Z=k|X=xᵢ) = (pₖfₖ(xᵢ))/(∑ₗpₗfₗ(xᵢ))
                                       # Comme on vise la log-vraisemblance, on calcule directement les logs des opérandes impliqués
                                       # Attention, EXPECTATION() retourne log((∑ₗpₗfₗ)

                                       log_somme_densites_ponderes <- EXPECTATION(X)

                                       # Étape M : mise à jour des paramètres
                                       # pₖ^new = (1/n)∑ᵢtₖ(xᵢ)
                                       # μₖ^new = (∑ᵢtₖ(xᵢ)xᵢ)/(∑ᵢtₖ(xᵢ))
                                       # Σₖ^new selon type_covariance
                                       MAXIMISATION(X)

                                       # Calcul de la log-vraisemblance courante et mise à jour historique
                                       log_vraisemblance_estimee_ <<- calculer_logvraisemblance(log_somme_densites_ponderes)

                                       evolution_logvraisemblance_estimee_initialisation_courante <- c(evolution_logvraisemblance_estimee_initialisation_courante, log_vraisemblance_estimee_)

                                       if(n > 1) {
                                         rel_change <- abs(log_vraisemblance_estimee_ - log_vraisemblance_estimee_precedente)/abs(log_vraisemblance_estimee_precedente)
                                         evolution_relative_lv_init <- c(evolution_relative_lv_init, rel_change)

                                         if(rel_change < epsilon_convergence) {
                                           etat_convergence_ <<- TRUE
                                           break
                                         }
                                       }
                                     }

                                     # A chaque initialisation, garder l'historique du meilleur ajustement
                                     if(log_vraisemblance_estimee_ > meilleur_resultat_logvraisemblance) {
                                       meilleur_resultat_logvraisemblance <- log_vraisemblance_estimee_
                                       meilleurs_parametres <- list(
                                         weights = proportions_,
                                         means = moyennes_,
                                         covariances = covariances_,
                                         n_iter = n,
                                         lower_bound = log_vraisemblance_estimee_,
                                         converged = etat_convergence_,
                                         evolution_logvraisemblance_estimee = evolution_logvraisemblance_estimee_initialisation_courante,
                                         evolution_relative_lv = evolution_relative_lv_init
                                       )
                                     }
                                   }

                                   # Attribution des meilleurs paramètres ajustés
                                   # et sauvegarde des infos de l ajustement qui les a produites
                                   proportions_ <<- meilleurs_parametres$weights
                                   moyennes_ <<- meilleurs_parametres$means
                                   covariances_ <<- meilleurs_parametres$covariances
                                   nb_iterations_realisees_ <<- meilleurs_parametres$n_iter
                                   log_vraisemblance_estimee_ <<- meilleurs_parametres$lower_bound
                                   etat_convergence_ <<- meilleurs_parametres$converged
                                   evolution_logvraisemblance_estimee <<- meilleurs_parametres$evolution_logvraisemblance_estimee
                                   evolution_relative_lv <<- meilleurs_parametres$evolution_relative_lv




                                   invisible(NULL)
                                 },

                                 ## INITIALISATION DES PARAMETRES PROPORTIONS MOYENNES COVS #####################

                                 # Initialisation des paramètres du modèle de mélange gaussien
                                 # Cette fonction initialise les trois ensembles de paramètres θ⁽⁰⁾ = (pₖ⁽⁰⁾, μₖ⁽⁰⁾, Σₖ⁽⁰⁾) :
                                 # 1. Proportions pₖ du mélange (K paramètres avec Σpₖ = 1)
                                 # 2. Moyennes μₖ des composantes (K×p paramètres)
                                 # 3. Matrices de covariance Σₖ (K×p×p ou moins selon 'hypothèse de simplification)

                                 initialiser_parametres = function(X) {
                                   n_samples <- nrow(X)
                                   n_features <- ncol(X)

                                   # 1. Initialisation naive des proportions
                                   # H₀ : équiprobabilité des classes
                                   # pₖ⁽⁰⁾ = 1/K pour tout k
                                   proportions_ <<- rep(1 / nb_clusters, nb_clusters)

                                   # 2. Initialisation des moyennes
                                   # Deux stratégies disponibles selon le risque de maxima locaux :
                                   if (comment_initialiser_parametres == "kmeans") {
                                     # Stratégie : K-means
                                     # Avantages :
                                     # - Points initiaux plus espacés
                                     # - Meilleure convergence empirique
                                     km <- kmeans(X, centers = nb_clusters)
                                     moyennes_ <<- km$centers
                                   } else if (comment_initialiser_parametres == "random") {
                                     if (!is.null(random_state)) {
                                       set.seed(random_state)
                                     }
                                     # Stratégie 2 : Échantillonnage aléatoire
                                     # μₖ⁽⁰⁾ ~ U({x₁,...,xₙ}) pour k = 1,...,K
                                     # Avantages :
                                     # - Simple et rapide
                                     # - Exploration plus large de l'espace des paramètres
                                     # En pratique :
                                     # - Tire K observations aléatoirement sans remise parmi les n disponibles
                                     # - Chaque observation tirée devient un centre initial μₖ⁽⁰⁾
                                     moyennes_ <<- X[sample(1:n_samples, nb_clusters), ]
                                   } else {
                                     print("Cette méthode d'initialisation n'est pas implémentée, choisir kmeans ou random")
                                   }


                                   # 3. Initialisation des matrices de covariance
                                   # Principe : partir de la variabilité globale des données
                                   # et l'adapter selon la structure imposée
                                   # il existe 4 structures implémentées possibles, de la plus générale à la plus contrainte :
                                   if (type_covariance == "full") {
                                     # Structure : Matrice de covariance complètes pour chaque cluster
                                     # Choix d'initialisation : Toutes les matrices de covariance Σₖ⁽⁰⁾ sont initialisées
                                     # à la matrice de covariance empirique globale des données X (cov(X)).
                                     # Cette initialisation produit des matrices de covariance complètes
                                     # (avec des termes hors diagonale), qui seront affinées lors de l ajustement
                                     # Matrice de Forme K*p*p
                                     covariances_ <<- array(0, dim = c(nb_clusters, n_features, n_features))
                                     for (k in 1:nb_clusters) {
                                       covariances_[k, , ] <<- cov(X)  # Variance des données par dimension
                                     }

                                   } else if (type_covariance == "tied") {
                                     # Structure 2 : Modèle "tied" sous l'hypothèse d'homoscédasticité
                                     # Tous les clusters partagent une unique matrice de covariance Σ commune.
                                     # Choix d'initialisation : Cette matrice de covariance commune est ici initiée
                                     # par la matrice de covariance empirique de l'ensemble des données.
                                     # Hypothèse forte : Homoscédasticité (les clusters ont la même forme et dispersion).
                                     # Matrice de forme p*p.
                                     covariances_ <<- cov(X)

                                   } else if (type_covariance == "diag") {
                                     # Structure 3 : Modèle "diag" (matrices de covariance diagonales distinctes par cluster)
                                     # Chaque cluster possède une matrice de covariance diagonale Σₖ, avec des variances
                                     # spécifiques à chaque variable.
                                     # Hypothèse d'indépendance conditionnelle des variables (orthogonales si appartenant à un même cluster)
                                     # Choix d'initialisation: toutes les matrices diagonales sont initialisées
                                     # avec les variances globales des variables dans X.
                                     # Forme Matrice diagonale p*p
                                     covariances_ <<- array(0, dim = c(nb_clusters, n_features, n_features))
                                     for (k in 1:nb_clusters) {
                                       covariances_[k, , ] <<- diag(apply(X, 2, var))
                                     }

                                   } else if (type_covariance == "spherical") {
                                     # Structure 4 : Modèle "spherical" (matrices de covariance sphériques)
                                     # Chaque cluster possède une matrice de covariance proportionnelle à l'identité,
                                     # où la variance est identique dans toutes les dimensions. Ici, cette variance
                                     # commune est initialisée à la moyenne des variances des variables dans X.
                                     # Hypothèse forte :
                                     # - Les dimensions sont indépendantes.
                                     # - La variance est identique dans toutes les dimensions au sein d’un cluster.
                                     # - Tous les clusters sont des hypersphères (orientations identiques).
                                     # Nombre de paramètres de variance libres : K (une variance σ² par cluster).
                                     avg_variance <- mean(apply(X, 2, var))
                                     covariances_ <<- array(0, dim = c(nb_clusters, n_features, n_features))
                                     for (k in 1:nb_clusters) {
                                       covariances_[k, , ] <<- diag(avg_variance, n_features)
                                     }
                                   }
                                 },


                                 ## EXPECTATION #################################################################

                                 # Objectif:
                                 # Calcul des probabilités conditionnelles (ou responsabilités) :
                                 #   tₖ(x) = P(Z = k|X = x) = P(Z = k|X = x,θ⁽ᵠ⁾)
                                 # où :
                                 #   - pₖ sont les proportions du mélange
                                 #   - fₖ(x) = 𝒩(x|μₖ,Σₖ) est la densité gaussienne du cluster
                                 # Stockage de tₖ(x) dans l'attribut qui lui est consacré (prob_z_sachant_x)
                                 #
                                 # Subtilité d'implémentation :
                                 # Implémentation numérique stable :
                                 # 1. Travail en log-échelle pour éviter les under/over flow et favoriser les additions aux multiplications
                                 #    log(tₖ(x)) = log(pₖ) + log(fₖ(x)) - log(∑ₗ pₗ fₗ(x))
                                 #
                                 # 2. Décomposition en deux étapes :
                                 #    a) log_densite_ponderee = log(pₖ) + log(fₖ(x))
                                 #    b) log_somme_densites_ponderes = log(∑ₗ pₗ fₗ(x))
                                 #
                                 # Retourne log(∑ₗ pₗ fₗ(x)) et stocke tₖ(x)


                                 EXPECTATION = function(X) {

                                   log_densite_ponderee <- estimer_log_densite_ponderee(X)
                                   log_somme_densites_ponderes <- estimer_log_somme_densites_ponderees(log_densite_ponderee)
                                   log_somme_densites_ponderes
                                 },

                                 ## MAXIMISATION ################################################################

                                 # Étape M : Mise à jour des paramètres θ⁽ᵠ⁺¹⁾ = (pₖ⁽ᵠ⁺¹⁾, μₖ⁽ᵠ⁺¹⁾, Σₖ⁽ᵠ⁺¹⁾)
                                 #
                                 # Formules théoriques  :
                                 # 1. Proportions : pₖ⁽ᵠ⁺¹⁾ = (1/n)∑ᵢ tₖ(xᵢ)
                                 # 2. Moyennes : μₖ⁽ᵠ⁺¹⁾ = (∑ᵢ tₖ(xᵢ)xᵢ)/(∑ᵢ tₖ(xᵢ))
                                 # 3. Covariances : Σₖ⁽ᵠ⁺¹⁾ = (∑ᵢ tₖ(xᵢ)(xᵢ-μₖ)(xᵢ-μₖ)ᵀ)/(∑ᵢ tₖ(xᵢ))


                                 MAXIMISATION = function(X) {

                                   n_samples <- nrow(X)

                                   # MAJ proportions
                                   # pₖ⁽ᵠ⁺¹⁾ = (1/n)∑ᵢ tₖ(xᵢ)
                                   proportions_ <<- colSums(prob_z_sachant_x_) / n_samples

                                   # MAJ moyennes
                                   # a) Numérateur : ∑ᵢ tₖ(xᵢ)xᵢ
                                   X_sum_ponderee_par_tk <- t(prob_z_sachant_x_) %*% X
                                   # b) Dénominateur : nₖ = ∑ᵢ tₖ(xᵢ)
                                   nk <- colSums(prob_z_sachant_x_)  # K
                                   # c) Division : μₖ = (∑ᵢ tₖ(xᵢ)xᵢ)/(∑ᵢ tₖ(xᵢ))
                                   moyennes_ <<- as.matrix(sweep(X_sum_ponderee_par_tk, 1, nk, "/"))


                                   # MAJ des covariances Σₖ
                                   # Via fonction dédiée selon type_covariance
                                   update_covariances(X)

                                 },


                                 ## MAJ COVARIANCES SELON HYPOTHESE DU MODELE ###################################

                                 # Mise à jour des matrices de covariance selon les 4 structures implémentées :
                                 # 1. "full" : Matrices Σₖ complètes et distinctes pour chaque cluster k
                                 #    - Formule : Σₖ = (1/nₖ)∑ᵢ tₖ(xᵢ)(xᵢ-μₖ)(xᵢ-μₖ)ᵀ
                                 #    - Pas d'hypothèse restrictive sur la forme
                                 #
                                 # 2. "tied" : Une seule matrice Σ partagée par tous les clusters
                                 #    - Hypothèse d'homoscédasticité : Σₖ = Σ ∀k
                                 #    - Clusters de même forme/dispersion
                                 #
                                 # 3. "diag" : Matrices diagonales Σₖ distinctes
                                 #    - Hypothèse d'indépendance conditionnelle des variables
                                 #    - Axes principaux alignés avec les axes des features
                                 #
                                 # 4. "spherical" : Matrices sphériques Σₖ = σₖ²I
                                 #    - Hypothèse la plus restrictive
                                 #    - Clusters sphériques de rayons différents
                                 #
                                 # Arguments:
                                 #   X : Matrice n×p des observations
                                 #
                                 # Note : Une régularisation est ajoutée à la diagonale des matrices de covariance obtenues
                                 # afin d'éviter des problèmes d'inversibilité lors du calcul de la densité avec la param cov

                                 update_covariances = function(X) {
                                   "Mise à jour des matrices de covariance"
                                   n_samples <- nrow(X)
                                   n_features <- ncol(X)

                                   if (type_covariance == "full") {

                                     # Type "full"
                                     # Implémente la formule théorique du cours : Σₖ = (1/nₖ)∑ᵢtₖ(xᵢ)(xᵢ-μₖ)(xᵢ-μₖ)ᵀ

                                     covariances_ <<- array(0, dim = c(nb_clusters, n_features, n_features))
                                     for (k in 1:nb_clusters) {
                                       diff <- sweep(X, 2, moyennes_[k, ], "-") # (xᵢ-μₖ)
                                       tk <- prob_z_sachant_x_[, k]
                                       cov <- t(diff) %*% (diff * tk) / sum(tk) # Σₖ avec tk = tₖ(xᵢ)

                                       # Ajout de la régularisation
                                       cov <- cov + diag(regul_inversibilite, n_features)
                                       covariances_[k, , ] <<- cov
                                     }

                                   } else if (type_covariance == "tied") {
                                     # Dans le modèle "tied", tous les clusters partagent une unique matrice de covariance,
                                     # notée Σ_shared. Cette matrice capture la variance globale des données, tout en
                                     # prenant en compte les responsabilités tₖ(xᵢ) (probabilités d'appartenance de xᵢ
                                     # au cluster k). Le calcul repose sur la formule suivante :
                                     #
                                     # Σ_shared = (1 / ∑ᵢ ∑ₖ tₖ(xᵢ)) * ∑ₖ ∑ᵢ tₖ(xᵢ) (xᵢ - μₖ)(xᵢ - μₖ)ᵀ

                                     covariance_shared <- matrix(0, n_features, n_features)
                                     for (k in 1:nb_clusters) {
                                       diff <- sweep(X, 2, moyennes_[k, ], "-") # Calcul de (xᵢ - μₖ) pour le cluster k
                                       tk <- prob_z_sachant_x_[, k] # tₖ(xᵢ) :probabilités a posteriori pour le cluster k
                                       covariance_shared <- covariance_shared + (t(diff) %*% (diff * tk)) # Contribution du cluster k
                                     }
                                     covariance_shared <- covariance_shared / n_samples
                                     covariance_shared <- covariance_shared + diag(regul_inversibilite, n_features)
                                     covariances_ <<- covariance_shared

                                   } else if (type_covariance == "diag") {
                                     # Dans le modèle "diag", chaque cluster possède une matrice de covariance diagonale.
                                     # Cela signifie que seules les variances (éléments sur la diagonale) sont modélisées
                                     # pour chaque cluster, et les covariances (éléments hors diagonale) sont supposées nulles.
                                     #
                                     # Formule pour les variances diagonales :
                                     # var_diag[k, j] = (1 / nₖ) ∑ᵢ tₖ(xᵢ) * (xᵢ[j] - μₖ[j])²
                                     covariances_ <<- array(0, dim = c(nb_clusters, n_features, n_features))
                                     for (k in 1:nb_clusters) {
                                       diff <- sweep(X, 2, moyennes_[k, ], "-") # Calcul de (xᵢ - μₖ) pour le cluster k
                                       tk <- prob_z_sachant_x_[, k] # tₖ(xᵢ) :probabilités a posteriori pour le cluster k
                                       var_diag <- colSums((diff^2) * tk) / sum(tk)  # Variance pour chaque dimension
                                       covariances_[k, , ] <<- diag(var_diag + regul_inversibilite) # Matrice diagonale avec régularisation
                                     }

                                   } else if (type_covariance == "spherical") {
                                     # Dans le modèle "spherical", chaque cluster possède une matrice de covariance
                                     # proportionnelle à l'identité : Σₖ = σₖ² * I. Cela signifie que :
                                     # - La variance est identique dans toutes les dimensions pour un cluster donné.
                                     # - La matrice de covariance est diagonale avec la même valeur σₖ² sur toute
                                     #   la diagonale.
                                     #
                                     # Formule pour la variance moyenne σₖ² d’un cluster k :
                                     # avg_variance[k] = (1 / (nₖ * p)) ∑ᵢ tₖ(xᵢ) ∑ⱼ (xᵢⱼ - μₖⱼ)²
                                     covariances_ <<- array(0, dim = c(nb_clusters, n_features, n_features))
                                     for (k in 1:nb_clusters) {
                                       diff <- sweep(X, 2, moyennes_[k, ], "-")
                                       tk <- prob_z_sachant_x_[, k]
                                       avg_variance <- sum((diff^2) * tk) / (sum(tk) * n_features)  # Variance moyenne σₖ²
                                       covariances_[k, , ] <<- diag(avg_variance + regul_inversibilite, n_features) # Σₖ = σₖ² * I (ramener à une matrice diagonale)
                                     }
                                   }
                                 },

                                 ## LOG DENSITES PONDEREES PAR PRPORTIONS #######################################

                                 # Calcule log(pₖ fₖ(x)) pour chaque observation x et chaque cluster k
                                 # En utilisant la propriété log(ab) = log(a) + log(b)
                                 #
                                 # Arguments:
                                 #   X : Matrice n×p des observations
                                 #
                                 # Détails:
                                 # 1. Calcule log(fₖ(x)) via estimer_log_densite()
                                 # 2. Calcule log(pₖ) des proportions des clusters
                                 # 3. Additionne les logs : log(pₖ) + log(fₖ(x))
                                 #
                                 # Retourne:
                                 #   Matrice n×K des log-densités pondérées log(pₖ fₖ(x))

                                 estimer_log_densite_ponderee = function(X) {

                                   log_prob <- estimer_log_densite(X)
                                   log_proportions <- log(proportions_)
                                   log_densite_ponderee <- sweep(log_prob, 2, log_proportions, "+")
                                   log_densite_ponderee
                                 },


                                 ## LOG DENSITES POUR TOUTES LES GAUSSIENNEs ####################################

                                 # Calcule log(fₖ(x)) pour chaque observation x et chaque composante k
                                 # où fₖ est la densité gaussienne de paramètres (μₖ,Σₖ)
                                 #
                                 # Arguments:
                                 #   X : Matrice n×p des observations
                                 #
                                 # Détails:
                                 # - Pour chaque cluster k=1,...,K :
                                 #   1. Récupère les paramètres (μₖ,Σₖ)
                                 #   2. Calcule log(fₖ(x)) via estimer_log_gaussian()
                                 #
                                 # Retourne:
                                 #   Matrice n×K des log-densités : [log(fₖ(xᵢ))]ᵢₖ

                                 estimer_log_densite = function(X) {
                                   "estimation des log-probabilités sous chaque gaussienne"
                                   n_samples <- nrow(X)
                                   n_features <- ncol(X)

                                   log_prob <- matrix(0, nrow = n_samples, ncol = nb_clusters)

                                   for(k in 1:nb_clusters) {
                                     log_prob[, k] <- estimer_log_gaussian(X, k)
                                   }

                                   log_prob
                                 },

                                 ## LOG PROBABLITES SOUS GAUSSIENNE k ###########################################

                                 # Calcule log(fₖ(x)) pour la composante k du mélange, où fₖ est la densité
                                 # gaussienne multivariée N(μₖ,Σₖ)
                                 #
                                 # Arguments:
                                 #   X : Matrice n×p des observations
                                 #   k : Indice du cluster (1 à K)
                                 #
                                 # Détails du calcul de la log-densité gaussienne :
                                 # log(fₖ(x)) = -0.5[p log(2π) + log|Σₖ| + (x-μₖ)ᵀΣₖ⁻¹(x-μₖ)]
                                 #
                                 # Étapes:
                                 # 1. Récupère μₖ et Σₖ selon type_covariance
                                 # 2. Calcule log|Σₖ| via SVD pour stabilité numérique
                                 # 3. Calcule (x-μₖ)ᵀΣₖ⁻¹(x-μₖ) via pseudo-inverse SVD
                                 #
                                 # Note:
                                 # - SVD utilisée plutôt que Cholesky pour plus de stabilité
                                 # - Pseudo-inverse gère les cas de matrices mal conditionnées

                                 estimer_log_gaussian = function(X, k) {
                                   "estimation de la log-probabilité sous la gaussienne k"
                                   n_samples <- nrow(X)
                                   n_features <- ncol(X)

                                   # Récupération des paramètres pour le composant k
                                   mu <- moyennes_[k, ]

                                   # Sélection de la matrice de covariance en fonction du type
                                   if (type_covariance == "full") {
                                     cov_k <- covariances_[k, , ]
                                   } else if (type_covariance == "tied") {
                                     cov_k <- covariances_
                                   } else if (type_covariance == "diag") {
                                     cov_k <- diag(diag(covariances_[k, , ]))
                                   } else if (type_covariance == "spherical") {
                                     cov_k <- diag(covariances_[k, 1, 1], n_features)
                                   }

                                   # Utilisation de SVD pour décomposer la matrice de covariance
                                   svd_cov <- svd(cov_k)

                                   # Calcul du déterminant logarithmique de la covariance
                                   log_det_cov <- sum(log(svd_cov$d))

                                   # Calcul du terme quadratique
                                   diff <- sweep(X, 2, mu, "-")
                                   inv_cov_k <- svd_cov$u %*% diag(1 / svd_cov$d) %*% t(svd_cov$u) # Pseudo-inverse via SVD
                                   quad <- rowSums((diff %*% inv_cov_k) * diff)

                                   # Retour de la log-probabilité
                                   -0.5 * (n_features * log(2 * pi) + log_det_cov + quad)
                                 },


                                 ## PROBABILITES CLUSTERS A POSTERIORI ##########################################

                                 # Calcule tₖ(x) = P(Z=k|X=x) à partir des log(pₖfₖ(x))
                                 # et
                                 # Calcule en log-échelle pour stabilité numérique:
                                 # 1. log(∑ₖpₖfₖ(x)) via logsumexp()
                                 # 2. log(tₖ(x)) = log(pₖfₖ(x)) - log(∑ₗpₗfₗ(x))
                                 # 3. tₖ(x) = exp(log(tₖ(x)))
                                 #
                                 # Arguments:
                                 #   log_densite_ponderee: Matrice n×K des log(pₖfₖ(x))
                                 #
                                 # Calculs en log-échelle pour stabilité numérique:
                                 # 1. log(∑ₖpₖfₖ(x)) via logsumexp()
                                 # 2. log(tₖ(x)) = log(pₖfₖ(x)) - log(∑ₗpₗfₗ(x))
                                 # 3. tₖ(x) = exp(log(tₖ(x)))
                                 #
                                 # Retourne:
                                 #   - Stocke tₖ(x) dans prob_z_sachant_x_
                                 #   - Retourne log(∑ₖpₖfₖ(x))

                                 estimer_log_somme_densites_ponderees = function(log_densite_ponderee) {

                                   log_somme_densites_ponderes <- apply(log_densite_ponderee, 1, logsumexp)
                                   log_prob_z_sachant_x <- sweep(log_densite_ponderee, 1, log_somme_densites_ponderes, "-")
                                   prob_z_sachant_x_ <<- exp(log_prob_z_sachant_x) # stocker nos tk
                                   log_somme_densites_ponderes
                                 },

                                 ## LOGVRAISEMBLANCE 1  #########################################################

                                 # Calcule la moyenne de la log-vraisemblance estimée:
                                 #   ℓ(θ) = (1/n)∑ᵢ log(∑ₖ pₖfₖ(xᵢ))
                                 #
                                 # Arguments:
                                 #   log_somme_densites_ponderes: Vecteur des log(∑ₖpₖfₖ(xᵢ))
                                 #
                                 # Note: normalisation par le nombre d'échantillons
                                 #       Est appelée pendant l'algorithme EM
                                 #       Reçoit directement les log-sommes déjà calculées
                                 #
                                 # Utilisée pour:
                                 # - Vérifier la convergence de l'algorithme EM
                                 # - Choisir la meilleure initialisation
                                 # - Calculer les critères AIC et BIC

                                 calculer_logvraisemblance = function(log_somme_densites_ponderes) {

                                   sum(log_somme_densites_ponderes) / length(log_somme_densites_ponderes)
                                 },

                                 ## LOGVRAISEMBLANCE 2, SCORE A PARTIR X ########################################

                                 # Calcule la vraisemblance à partir du dataset
                                 # Utilisable après ajustement

                                 score = function(X) {
                                   "Calcul de la log-vraisemblance moyenne"
                                   log_densite_ponderee <- estimer_log_densite_ponderee(X)
                                   log_somme_densites_ponderes <- apply(log_densite_ponderee, 1, logsumexp)
                                   mean(log_somme_densites_ponderes)
                                 },


                                 ## CLUSTER ESTIME PAR MAXIMUM A POSTERIORI #####################################

                                 # Implémente la règle de classification MAP (Maximum A Posteriori):
                                 #   k*(x) = argmax_k P(Z=k|X=x) = argmax_k log(pₖfₖ(x))
                                 #
                                 # Arguments:
                                 #   X: Matrice n×p des observations à classifier
                                 #
                                 # Retourne:
                                 #   Un vecteur de taille n contenant l'indice du cluster le plus probable
                                 #   pour chaque observation selon la règle MAP
                                 #
                                 # Note: Cette règle correspond au classifieur de Bayes optimal
                                 # dans le cas de coûts de mauvaise classification égaux

                                 predict = function(X) {

                                   log_densite_ponderee <- estimer_log_densite_ponderee(X)
                                   max_indices <- apply(log_densite_ponderee, 1, which.max)
                                   max_indices
                                 },



                                 ## NOMBRE PARAMETRES DU MODELE #################################################

                                 # Calcule le nombre total de paramètres libres du modèle selon sa structure
                                 #
                                 # Détails du calcul:
                                 # 1. Moyennes: K×p paramètres
                                 # 2. Proportions: K-1 paramètres (Σpₖ=1)
                                 # 3. Covariances selon type:
                                 #    - "full": K×p×(p+1)/2 paramètres
                                 #    - "tied": p×(p+1)/2 paramètres
                                 #    - "diag": K×p paramètres
                                 #    - "spherical": K paramètres
                                 #
                                 # Utilisé pour:
                                 # - Calcul des critères BIC et AIC
                                 # - Évaluation de la complexité du modèle
                                 #
                                 # Note: (p+1)/2 vient du fait que Σₖ est symétrique

                                 n_parameters = function() {

                                   n_features <- ncol(moyennes_)

                                   # Paramètres des moyennes
                                   n_params_means <- nb_clusters * n_features

                                   # Paramètres des poids
                                   n_params_weights <- nb_clusters - 1 # -1 vu que une est déductible de la valeurs des autres

                                   # Paramètres des covariances
                                   n_params_cov <- switch(type_covariance,
                                                          "full" = nb_clusters * n_features * (n_features + 1) / 2,
                                                          "tied" = n_features * (n_features + 1) / 2,
                                                          "diag" = nb_clusters * n_features,
                                                          "spherical" = nb_clusters
                                   )

                                   n_params_means + n_params_weights + n_params_cov
                                 },


                                 ## BIC #########################################################################

                                 # Calcule le critère BIC pour la sélection de modèle:
                                 #   BIC = -2 log L(θ) + ν log(n)
                                 # où:
                                 #   - L(θ): vraisemblance aux paramètres estimés
                                 #   - ν: nombre de paramètres libres
                                 #   - n: taille de l'échantillon
                                 #
                                 # Pénalise la complexité du modèle (ν) de façon croissante avec n
                                 #
                                 # Usage:
                                 # - Sélection du nombre optimal de composantes K
                                 # - Choix de la structure de covariance
                                 #
                                 # Note: dans notre implémentation, le meilleur modèle minimise le BIC

                                 bic = function(X) {

                                   n_samples <- nrow(X)
                                   -2 * (score(X) * n_samples) + (n_parameters() * log(n_samples))
                                 },


                                 ## AIC #########################################################################

                                 # Calcule le critère AIC pour la sélection de modèle:
                                 #   AIC = -2 log L(θ) + 2ν
                                 # où:
                                 #   - L(θ): vraisemblance aux paramètres estimés
                                 #   - ν: nombre de paramètres libres
                                 #
                                 # Différence avec BIC:
                                 # - Pénalisation fixe (2ν) indépendante de n
                                 # - Moins conservateur que BIC
                                 # - Tend à sélectionner des modèles plus complexes
                                 #
                                 # Note: dans notre implémentation, le meilleur modèle minimise l'AIC

                                 aic = function(X) {

                                   n_samples <- nrow(X)
                                   -2 * score(X) * n_samples + 2 * n_parameters()
                                 },

                                 ## FONCTIONS GRAPHIQUES : ######################################################

                                 #### GRAPHIQUE EVOLUTION LV ####################################################

                                 ## VISUALISATION DE LA CONVERGENCE #############################################

                                 # Trace l'évolution de la log-vraisemblance au cours des itérations
                                 #
                                 # Arguments:
                                 #
                                 #   type: "logvraisemblance" ou "evolution relative"
                                 #      - "logvraisemblance": ℓ(θ⁽ᵠ⁾) vs φ
                                 #      - "evolution relative": |ℓ(θ⁽ᵠ⁺¹⁾)-ℓ(θ⁽ᵠ⁾)|/|ℓ(θ⁽ᵠ⁾)| vs φ
                                 #
                                 # Graphiques produits:
                                 # 1. Log-vraisemblance:
                                 #    - Ordonnée: valeur de ℓ(θ⁽ᵠ⁾)
                                 #    - Abscisse: itération φ
                                 #    - Ligne verticale à convergence
                                 #
                                 # 2. Evolution relative:
                                 #    - Ordonnée: variation relative δ⁽ᵠ⁾
                                 #    - Abscisse: itération φ
                                 #    - Montre la stabilisation

                                 plot_convergence = function(type = c("logvraisemblance", "evolution relative")) {

                                   type <- match.arg(type)

                                   if(!requireNamespace("ggplot2", quietly = TRUE)) {
                                     stop("Veuillez installer le package ggplot2")
                                   }

                                   # Préparation des données
                                   if(type == "logvraisemblance") {
                                     df <- data.frame(
                                       iteration = 1:length(evolution_logvraisemblance_estimee),
                                       value = evolution_logvraisemblance_estimee
                                     )
                                     title <- "Évolution de la log-vraisemblance"
                                     ylab <- "log-vraisemblance"
                                   } else {
                                     df <- data.frame(
                                       iteration = 2:(length(evolution_logvraisemblance_estimee)),
                                       value = evolution_relative_lv
                                     )
                                     title <- "Evolution relative"
                                     ylab <- "δ⁽ᵠ⁾ = |ℓ(θ⁽ᵠ⁺¹⁾) - ℓ(θ⁽ᵠ⁾)| / |ℓ(θ⁽ᵠ⁾)|"
                                   }

                                   # Création du graphique
                                   p <- ggplot2::ggplot(df, ggplot2::aes(x = iteration, y = value)) +
                                     ggplot2::geom_line(color = "blue") +
                                     ggplot2::geom_point(color = "blue", size = 2) +
                                     ggplot2::labs(
                                       title = title,
                                       x = "Itération",
                                       y = ylab
                                     ) +
                                     ggplot2::theme_minimal()

                                   if(etat_convergence_) {
                                     p <- p + ggplot2::geom_vline(
                                       xintercept = nb_iterations_realisees_,
                                       linetype = "dashed",
                                       color = "red"
                                     )
                                   }

                                   print(p)
                                 },

                                 #### GRAPHIQUE ClUSTERS 2D #####################################################

                                 # Représente les clusters dans un plan 2D avec ellipses de confiance
                                 #
                                 # Arguments:
                                 #   X: Matrice des données
                                 #   dims: Indices des 2 dimensions à visualiser (défaut: [1,2])
                                 #
                                 # Éléments du graphique:
                                 # - Points: observations colorées selon leur cluster
                                 # - Ellipses: contours de niveau des gaussiennes ajustées
                                 # - Alpha: 0.6 pour voir les superpositions
                                 #
                                 # Note: Les ellipses correspondent aux contours
                                 # d'iso-probabilité des gaussiennes estimées

                                 plot_clusters = function(X, dims = c(1,2)) {
                                   "Visualisation des affectations de clusters"
                                   if(!requireNamespace("ggplot2", quietly = TRUE)) {
                                     stop("Veuillez installer le package ggplot2")
                                   }

                                   if(ncol(X) < 2) stop("Les données doivent avoir au moins 2 dimensions")

                                   clusters <- predict(X)

                                   df <- data.frame(
                                     x = X[,dims[1]],
                                     y = X[,dims[2]],
                                     cluster = factor(clusters)
                                   )

                                   p <- ggplot2::ggplot(df, ggplot2::aes(x = x, y = y, color = cluster)) +
                                     ggplot2::geom_point(alpha = 0.6) +
                                     ggplot2::stat_ellipse(type = "norm") +
                                     ggplot2::labs(
                                       title = "Résultats du clustering par Melange Gaussien",
                                       x = paste("Dimension", dims[1]),
                                       y = paste("Dimension", dims[2])
                                     ) +
                                     ggplot2::theme_minimal()

                                   print(p)
                                 },

                                 ## SELECTION NB CLUSTERS #######################################################

                                 # Détermine le nombre optimal K de composantes via AIC ou BIC
                                 #
                                 # Arguments:
                                 #   X: Données
                                 #   min_clusters, max_clusters: Plage de K à tester
                                 #   criterion: "bic" ou "aic"
                                 #
                                 # Procédure:
                                 # 1. Pour chaque K dans [min_clusters, max_clusters]:
                                 #    - Ajuste le modèle
                                 #    - Calcule le critère (AIC/BIC)
                                 #    - Stocke le résultat
                                 #
                                 # 2. Visualisation:
                                 #    - Courbe criterion vs K
                                 #    - Ligne verticale au K optimal
                                 #
                                 # Retourne:
                                 #   - best_nb_clusters: K optimal (minimisant le critère)
                                 #   - results: Data frame des valeurs pour chaque K

                                 select_best_nb_clusters = function(X, min_clusters=2,
                                                                    max_clusters=9,
                                                                    criterion=c("bic", "aic")) {

                                   # Vérification des arguments
                                   if (min_clusters < 2) {
                                     stop("Erreur : min_clusters doit être supérieur ou égal à 2.")
                                   }

                                   if (max_clusters <= min_clusters) {
                                     stop("Erreur : max_clusters doit être strictement supérieur à min_clusters.")
                                   }

                                   criterion <- match.arg(criterion)

                                   results <- data.frame(
                                     nb_clusters = min_clusters:max_clusters,
                                     criterion_value = NA
                                   )

                                   for(n in min_clusters:max_clusters) {
                                     nb_clusters <<- n
                                     fit(X)

                                     results$criterion_value[results$nb_clusters == n] <-
                                       if(criterion == "bic") bic(X) else aic(X)
                                   }

                                   best_n <- results$nb_clusters[which.min(results$criterion_value)]

                                   if(requireNamespace("ggplot2", quietly = TRUE)) {
                                     p <- ggplot2::ggplot(results, ggplot2::aes(x=nb_clusters, y=criterion_value)) +
                                       ggplot2::geom_line() +
                                       ggplot2::geom_point() +
                                       ggplot2::geom_vline(xintercept=best_n, linetype="dashed", color="red") +
                                       ggplot2::labs(
                                         title=paste("Sélection du modèle en utilisant", toupper(criterion)),
                                         x="Nombre de composantes",
                                         y=toupper(criterion)
                                       ) +
                                       ggplot2::theme_minimal()
                                     print(p)
                                   }

                                   list(
                                     best_nb_clusters = best_n,
                                     results = results
                                   )
                                 }
                               )
)

## FIN DE LA CLASSE MELANGE GAUSSIEN ###########################################


# FONCTION AUXILIAIRE ##########################################################

# Calcule log(∑exp()) de façon numériquement stable
# Utilisée dans l'étape E de l'EM pour calculer:
#   log(∑ₖpₖfₖ(x)) = log(∑exp(log(pₖfₖ(x))))
#
# Principe mathématique:
# 1. Extraction du maximum: m = max(xᵢ)
# 2. Réécriture: log(∑exp(xᵢ)) = m + log(∑exp(xᵢ-m))

################################################################################

logsumexp <- function(x) {
  # Étape 1 : Trouver le maximum des éléments de x et factoriser avec
  x_max <- max(x)
  # Étape 2 : Appliquer la reformulation mathématique
  # log(sum(exp(x))) = x_max + log(sum(exp(x - x_max)))
  # Ici, x_max est soustrait de chaque élément de x avant de prendre l'exponentielle.
  # Cela garantit que les arguments de la fonction exp(x - x_max) sont tous < 1
  result <- x_max + log(sum(exp(x - x_max)))
  # Retourner le résultat final : une estimation stable numériquement de log(sum(exp(x))).
  return(result)
}


