# ============================================================================ #
#                    TEST DE LA CLASSE MELANGEGAUSSIEN :
#                   Modèle Complet et initialisation random
# ============================================================================ #


# ---------------------------------------------------------------------------- #
#                        1. CRÉATION DES DONNÉES                               #
# ---------------------------------------------------------------------------- #

set.seed(42);
X <- rbind(
  # Cluster 1 de 100 observations
  matrix(rnorm(200, mean = 2, sd = 1), ncol = 2),
  # Cluster 2 de 100 observations
  matrix(rnorm(200, mean = 10, sd = 2), ncol = 2),
  # Cluster 3 de 200 observations
  matrix(rnorm(400, mean = 20, sd = 0.5), ncol = 2)
);

# Création des labels y
y <- c(
  rep(1, 100),  # 100 observations pour le Cluster 1
  rep(2, 100),  # 100 observations pour le Cluster 2
  rep(3, 200)   # 200 observations pour le Cluster 3
)

# ---------------------------------------------------------------------------- #
#                     2. CRÉATION ET AJUSTEMENT DU MODÈLE                      #
# ---------------------------------------------------------------------------- #

# Création du modèle
mg <- MelangeGaussien$new(
  nb_clusters = 3,
  type_covariance = "full",
  epsilon_convergence = 1e-8,
  regul_inversibilite = 1e-10,
  nb_iterations_max = 50,
  nb_initialisations = 5,
  comment_initialiser_parametres = "random",
  random_state = 42
);

# Ajustement du modèle
mg$fit(X);

# ---------------------------------------------------------------------------- #
#                        3. ANALYSE DES RÉSULTATS                              #
# ---------------------------------------------------------------------------- #


# Paramètres estimés
cat("\n Proportions des clusters:\n");
print(mg$proportions_);
cat("\nMoyennes des clusters:\n");
print(mg$moyennes_);
cat("\nMatrices de covariance par cluster:\n");
for(k in 1:mg$nb_clusters) {
  cat("\nCluster", k, ":\n");
  print(mg$covariances_[k, , ]);
}

# Métriques de convergence
cat("\nNombre d'itérations:", mg$nb_iterations_realisees_);
cat("\nLog-vraisemblance finale:", mg$log_vraisemblance_estimee_);
cat("\nConvergence atteinte:", mg$etat_convergence_);

# ---------------------------------------------------------------------------- #
#                          4. VISUALISATIONS                                   #
# ---------------------------------------------------------------------------- #

mg$plot_convergence("logvraisemblance");
mg$plot_convergence("evolution relative");
mg$plot_clusters(X);

# ---------------------------------------------------------------------------- #
#                     5. ÉVALUATION DU MODÈLE                                  #
# ---------------------------------------------------------------------------- #

# Métriques
cat("\nScore (log-vraisemblance):", mg$score(X));
cat("\nCritère AIC:", mg$aic(X));
cat("\nCritère BIC:", mg$bic(X));
cat("\nNombre de paramètres:", mg$n_parameters());

# Prédictions
predictions <- mg$predict(X);
table(predictions, y )

# ---------------------------------------------------------------------------- #
#                 6. SÉLECTION DU NOMBRE DE CLUSTERS                           #
# ---------------------------------------------------------------------------- #

res_bic <- mg$select_best_nb_clusters(X, min_clusters=2, max_clusters=9, criterion="bic");
cat("\n Meilleur nombre de clusters selon BIC:", res_bic$best_nb_clusters);


res_aic <- mg$select_best_nb_clusters(X, min_clusters=2, max_clusters=9, criterion="aic");
cat("\nMeilleur nombre de clusters selon AIC:", res_aic$best_nb_clusters);

# ---------------------------------------------------------------------------- #
#                               FIN DES TESTS                                  #
# ---------------------------------------------------------------------------- #

cat("\nTous les tests ont été exécutés avec succès!")
