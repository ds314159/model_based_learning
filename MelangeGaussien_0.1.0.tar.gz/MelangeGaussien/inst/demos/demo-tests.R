# demo-tests.R

# Liste des fichiers de test
test_files <- c(
  "test_covariance_diag.R",
  "test_covariance_full.R",
  "test_covariance_spherical.R",
  "test_covariance_tied.R",
  "Code_principal_commente.R"
)

# Ouvrir chaque fichier dans RStudio
for(file in test_files) {
  file_path <- system.file("demos", file, package = "MelangeGaussien")
  file.edit(file_path)
}

cat("\n=== Instructions pour les tests ===\n")
cat("Les fichiers de test sont maintenant ouverts dans RStudio.\n")
cat("Chaque fichier teste une structure de covariance différente :\n")
cat("- test_covariance_diag.R : Matrice de covariance diagonale\n")
cat("- test_covariance_full.R : Matrice de covariance complète\n")
cat("- test_covariance_spherical.R : Matrice de covariance sphérique\n")
cat("- test_covariance_tied.R : Matrice de covariance commune\n\n")
cat("Pour exécuter les tests :\n")
cat("1. Sélectionnez un fichier à tester\n")
cat("2. Utilisez Ctrl/Cmd + Enter pour exécuter ligne par ligne\n")
cat("3. Ou Ctrl/Cmd + Shift + Enter pour exécuter tout le fichier\n")
